from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='Narzędzia wyszukiwania dla książki Python. Rusz głową!' ,
    author='Python. Rusz głową! Wydanie II' ,
    url='headfirstlabs.com' ,
    py_modules=['vsearch'],
)